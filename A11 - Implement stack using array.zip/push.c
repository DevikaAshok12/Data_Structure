#include "stack.h"

/* Fuction for inserting the element */
int Push(Stack_t *s, int data)
{
    if(is_stack_full(s) == SUCCESS)
    {
        return FAILURE;
    }
    s->top++;
    s->item[s->top]=data;
    return SUCCESS;
	


}