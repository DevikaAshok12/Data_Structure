#include "dll.h"

int dl_delete_list(Dlist **head, Dlist **tail)
{
    //not correct
    if(*head==NULL)
    {
        return FAILURE;
    }
    Dlist *temp=*head;
    Dlist *next;
    while(temp != NULL)
    {
        next=temp->next;
        free(temp);
        temp=next;
    }
    *head = NULL;  // Reset head pointer
    *tail = NULL;
    return SUCCESS;
    

}