#include "dll.h"

int dl_delete_last(Dlist **head, Dlist **tail)
{
   if(*head==NULL)
   {
       return FAILURE;
   }
   if(*tail==*head)
   {
       free(*head);
       *head=*tail=NULL;
       return SUCCESS;
       
   }
   (*tail)->prev->next=NULL;
   *tail=(*tail)->prev;
   free((*tail)->next);
   return SUCCESS;



}