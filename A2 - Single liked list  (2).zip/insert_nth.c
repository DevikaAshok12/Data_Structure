#include "sll.h"

int sl_insert_nth(Slist **head, data_t data, data_t n)
{
    Slist *new=malloc(sizeof(Slist));
    new->data=data;
    if(*head == NULL)
    {
        if(n==1)
        {
            *head=new;
            new->link=NULL;
            return SUCCESS;
        }
        else
        {
            return LIST_EMPTY;
        }
        
    }
    
    Slist *temp=*head;
    Slist *prev;
    int count=1;
    
    if(n==1)
    {
         new->link=*head;
        *head=new;
        return SUCCESS;
       
    }
    while(temp != NULL)
    {
        prev=temp;
        temp=temp->link;
        count++;
        if(count==n)
        {
            
            new->link=temp;
            prev->link=new;
            return SUCCESS;
        }
    }
    return POSITION_NOT_FOUND;
    
    
    

}