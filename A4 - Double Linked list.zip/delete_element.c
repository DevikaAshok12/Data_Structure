#include "dll.h"

int dl_delete_element(Dlist **head, Dlist **tail, int data)
{
    if(*head==NULL)
    {
        return LIST_EMPTY;
    }
    if(*tail==*head && ((*head)->data == data))
    {
        free(*head);
        *head=*tail=NULL;
        return SUCCESS;
    }
    Dlist *temp=*head;
    while(temp != NULL)
    {
        if(temp->data != data)
        {
            temp=temp->next;
            
        }
        else
        {                                                                                                                                                                                                                                                                                                                                                                                                                   
        if((*head)->data == data)
        {
            *head=temp->next;
            temp->next->prev=NULL;
            free(temp);
            return SUCCESS;
        }
        if((*tail)->data == data)
        {
            *tail=(*tail)->prev;
            free((*tail)->next);
            (*tail)->next=NULL;
            return SUCCESS;
        }
        
        
        temp->next->prev=temp->prev;
        temp->prev->next=temp->next;
        
        free(temp);
        return SUCCESS;
        }
    }

    

}