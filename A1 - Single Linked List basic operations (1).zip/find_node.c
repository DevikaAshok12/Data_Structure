#include "sll.h"

int find_node(Slist *head, data_t data)
{
    Slist *temp=head;
    int count=1;
    if(head == NULL)
    {
        return FAILURE;
    }
    while(temp != NULL)
    {
        if(temp->data == data)
        {
            return count;
        }
        temp=temp->link;
        count++;
    }
    return FAILURE;
	
}
